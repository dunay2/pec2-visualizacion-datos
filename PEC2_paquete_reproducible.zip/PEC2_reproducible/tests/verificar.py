"""Verifica los ejemplos y ejecuta las celdas del notebook; no publica nada."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile

import nbformat
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def ejecutar_script(datos, salida, sintetico=False):
    entorno = os.environ.copy()
    entorno.update(PEC2_DATA_DIR=str(datos), PEC2_OUTPUT_DIR=str(salida),
                   PEC2_ORIGEN_DATOS="local", PEC2_SWARM_RANGE="auto" if sintetico else "2500,6500",
                   PEC2_DEMO_LABEL="DATOS SINTÉTICOS · prueba de reutilización" if sintetico else "")
    subprocess.run([sys.executable, str(ROOT / "generar.py")], cwd=ROOT,
                   env=entorno, check=True)
    return json.loads((salida / "verificacion.json").read_text())


def comprobar_figuras(salida, esperados, originales):
    pie = json.loads((salida / "pie.json").read_text())
    velas = json.loads((salida / "candlestick.json").read_text())
    swarm = json.loads((salida / "beeswarm.json").read_text())
    informe = json.loads((salida / "verificacion.json").read_text())
    assert len(pie["data"]) == 1 and pie["data"][0]["type"] == "pie"
    assert len(velas["data"]) == 1 and velas["data"][0]["type"] == "candlestick"
    assert all(t["type"] == "scatter" for t in swarm["data"])
    assert len(pie["data"][0]["values"]) == esperados["categorias"]
    assert len(velas["data"][0]["x"]) == esperados["sesiones"]
    assert sum(len(t["x"]) for t in swarm["data"]) == esperados["puntos"]
    np.testing.assert_allclose(informe["pie"]["shares"], esperados["proporciones"], rtol=0, atol=1e-12)
    assert np.isclose(informe["pie"]["sum_shares"], 1)
    assert velas["data"][0]["x"] == sorted(velas["data"][0]["x"])
    assert len(velas["data"][0]["x"]) == len(set(velas["data"][0]["x"]))
    assert informe["beeswarm"]["missing_mass_excluded"] == esperados["excluidos"]
    assert not informe["beeswarm"]["placement_warnings"]
    for grupo in informe["beeswarm"]["groups"]:
        assert grupo["original_order_preserved"] and grupo["max_x_error"] == 0
        assert grupo["minimum_center_distance_px"] is None or (
            grupo["minimum_center_distance_px"] >= grupo["marker_diameter_px"] - 1e-6)
    assert swarm["layout"]["width"] == 1100 and swarm["layout"]["height"] == 550
    assert swarm["layout"]["margin"]["autoexpand"] is False
    assert swarm["layout"]["xaxis"]["fixedrange"] and swarm["layout"]["yaxis"]["fixedrange"]
    assert len(swarm["layout"]["shapes"]) == esperados["especies"]
    assert len(swarm["layout"]["annotations"]) == esperados["especies"]
    assert pie["layout"]["legend"]["itemclick"] is False
    assert pie["data"][0]["textposition"] == [
        "outside" if p < .1 else "inside" for p in esperados["proporciones"]]
    config = json.loads((salida / "plotly_config.json").read_text())
    assert config["beeswarm"]["responsive"] is False
    for nombre in ["pie", "candlestick", "beeswarm"]:
        assert '"bdata"' not in (salida / f"{nombre}.json").read_text()
        assert "plotly.js" in (salida / f"{nombre}.html").read_text().lower()
    # Contraste independiente con el CSV fuente, por número de registro original.
    entrada = pd.read_csv(originales / "penguins_original.csv")
    layout = pd.read_csv(salida / "beeswarm_layout.csv")
    assert layout.record_id.is_unique
    for fila in layout.itertuples(index=False):
        original = entrada.iloc[fila.source_row - 2]
        assert fila.species == original.species
        assert fila.body_mass_g == original.body_mass_g
    masas_plotly = {detalles[0]: masa for traza in swarm["data"]
                    for detalles, masa in zip(traza["customdata"], traza["x"])}
    assert masas_plotly == dict(zip(layout.record_id, layout.body_mass_g))
    return informe


notebook = nbformat.read(ROOT / "PEC2_visualizaciones.ipynb", as_version=4)
nbformat.validate(notebook)
codigo = "\n\n".join(c.source for c in notebook.cells if c.cell_type == "code")
for llamada in ["px.pie(", "go.Candlestick(", "sns.swarmplot("]:
    assert llamada in codigo

originales_esperados = dict(categorias=3, sesiones=11, puntos=342, excluidos=2, especies=3,
                           proporciones=[1035.5/1989.2, 135.9/1989.2, 817.8/1989.2])
sinteticos_esperados = dict(categorias=3, sesiones=4, puntos=11, excluidos=1, especies=2,
                           proporciones=[.45, .35, .20])
with tempfile.TemporaryDirectory(prefix="pec2_verificacion_") as temporal:
    base = Path(temporal)
    ejecutar_script(ROOT / "data", base / "original")
    a = comprobar_figuras(base / "original", originales_esperados, ROOT / "data")
    ejecutar_script(ROOT / "tests" / "datos_sinteticos", base / "sintetico", sintetico=True)
    b = comprobar_figuras(base / "sintetico", sinteticos_esperados, ROOT / "tests" / "datos_sinteticos")
    assert b["demo_label"].startswith("DATOS SINTÉTICOS")
    assert b["beeswarm"]["x_range"] != [2500.0, 6500.0]

    # Ejecutar las celdas como Python en orden, en un proceso limpio.
    # Esto prueba el cálculo; no afirma una prueba interactiva en el servicio Colab.
    celdas = [c.source for c in notebook.cells if c.cell_type == "code"]
    runner = base / "ejecutar_celdas.py"
    runner.write_text("celdas = " + repr(celdas) + "\n" +
                      "ambito = {'__name__': '__main__'}\n" +
                      "for i, celda in enumerate(celdas):\n" +
                      "    exec(compile(celda, f'<celda {i+1}>', 'exec'), ambito)\n", encoding="utf-8")
    entorno = os.environ.copy()
    entorno.update(PEC2_DATA_DIR=str(ROOT / "data"), PEC2_OUTPUT_DIR=str(base / "notebook"),
                   PEC2_ORIGEN_DATOS="local", PEC2_DEMO_LABEL="", PEC2_SWARM_RANGE="2500,6500")
    subprocess.run([sys.executable, str(runner)], cwd=ROOT, env=entorno, check=True)
    c = comprobar_figuras(base / "notebook", originales_esperados, ROOT / "data")
    for nombre in ["pie", "candlestick", "beeswarm"]:
        assert (base / "original" / f"{nombre}.json").read_bytes() == (
            base / "notebook" / f"{nombre}.json").read_bytes()

reporte = dict(
    result="PASS", notebook_format="nbformat.validate: PASS",
    notebook_execution="Celdas ejecutadas en orden como Python en un proceso nuevo; sin servicio Colab",
    notebook_and_script_figures_identical=True,
    script_sha256=hashlib.sha256((ROOT / "generar.py").read_bytes()).hexdigest(),
    notebook_sha256=hashlib.sha256((ROOT / "PEC2_visualizaciones.ipynb").read_bytes()).hexdigest(),
    original=a, synthetic=b,
)
(ROOT / "tests" / "resultado_pruebas.json").write_text(
    json.dumps(reporte, ensure_ascii=False, indent=2), encoding="utf-8")
print("PASS: originales, sintéticos, formato de cuaderno y ejecución de celdas.")
